// @ts-check
const { test, expect } = require('@playwright/test');

test('has title', async ({ page }) => {
  await page.goto('https://playwright.dev/', { timeout: 60000 });
  console.log(await page.title());  // Logs the title of the page to ensure it's loaded
  await expect(page).toHaveTitle(/Playwright/);
});

test('get started link', async ({ page }) => {
  await page.goto('https://playwright.dev/', { timeout: 60000 });
  console.log("Page loaded");  // Logs when the page has loaded
  
  const getStartedLink = await page.getByRole('link', { name: 'Get started' });
  await expect(getStartedLink).toBeVisible();
  await getStartedLink.click();

  const installationHeading = await page.getByRole('heading', { name: 'Installation' });
  await expect(installationHeading).toBeVisible();
});

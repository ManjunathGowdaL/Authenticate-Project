const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

(async () => {
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();

  // Create a folder for screenshots if it doesn't exist
  const screenshotDir = 'screenshots';
  if (!fs.existsSync(screenshotDir)) {
    fs.mkdirSync(screenshotDir);
  }

  const page = await context.newPage();

  // --- MYNTRA PLATFORM ---
  await page.goto('https://www.myntra.com/');

  // Search for a product on Myntra
  const searchTerm = 't-shirt';
  await page.fill('input[placeholder="Search for products, brands and more"]', searchTerm);
  await page.press('input[placeholder="Search for products, brands and more"]', 'Enter');

  // Wait for search results to load on Myntra
  await page.waitForSelector('.product-base');

  // Capture the link and price of the first product on Myntra and add to bag
  const myntraProductLink = await page.getAttribute('.product-base a', 'href');
  const myntraProductPrice = await page.textContent('.product-base .product-price');

  // Extract the numeric price value from the Myntra price
  const myntraPrice = parseFloat(myntraProductPrice.replace(/[^\d]/g, ''));
  const myntraProductFullLink = `https://www.myntra.com${myntraProductLink}`;
  console.log(`Myntra Product Link: ${myntraProductFullLink}`);
  console.log(`Myntra Product Price: ₹${myntraPrice}`);

  // Take screenshot of the Myntra product page
  const myntraScreenshotPath = path.join(screenshotDir, 'myntra_product.png');
  await page.screenshot({ path: myntraScreenshotPath });
  console.log(`Myntra Product Screenshot saved at: ${myntraScreenshotPath}`);

  // Clicking on the first product to view details
  await page.click('xpath=/html/body/div[2]/div/main/div[3]/div[2]/div/div[2]/section/ul/li[1]/a/div[1]');
  console.log('Clicked on the first product for detailed view');

  // Take screenshot of the detailed Myntra product page
  const myntraScreenshotPath2 = path.join(screenshotDir, 'myntra_tshirt.png');
  await page.screenshot({ path: myntraScreenshotPath2 });
  console.log(`Myntra Product Screenshot saved at: ${myntraScreenshotPath2}`);

  // --- AMAZON PLATFORM ---
  const amazonPage = await browser.newPage();
  await amazonPage.goto('https://www.amazon.in/');

  // Search for the same product on Amazon
  await amazonPage.fill('input#twotabsearchtextbox', searchTerm);
  await amazonPage.press('input#twotabsearchtextbox', 'Enter');

  // Wait for search results to load on Amazon
  await amazonPage.waitForSelector('.s-main-slot .s-result-item');

  // Capture the link and price of the first product on Amazon and add to bag
  const amazonProductLink = await amazonPage.getAttribute('.s-main-slot .s-result-item h2 a', 'href');
  const amazonProductPrice = await amazonPage.textContent('.s-main-slot .s-result-item span.a-price-whole');

  // Extract the numeric price value from the Amazon price
  const amazonPrice = parseFloat(amazonProductPrice.replace(/[^\d]/g, ''));
  const amazonProductFullLink = `https://www.amazon.in${amazonProductLink}`;
  console.log(`Amazon Product Link: ${amazonProductFullLink}`);
  console.log(`Amazon Product Price: ₹${amazonPrice}`);

  // Take screenshot of the Amazon product page
  const amazonScreenshotPath = path.join(screenshotDir, 'amazon_product.png');
  await amazonPage.screenshot({ path: amazonScreenshotPath });
  console.log(`Amazon Product Screenshot saved at: ${amazonScreenshotPath}`);

  // --- PRICE COMPARISON ---
  let comparisonResult = '';
  if (myntraPrice < amazonPrice) {
    comparisonResult = `Myntra offers the lowest price when compared to Amazon: ₹${myntraPrice}`;
  } else if (amazonPrice < myntraPrice) {
    comparisonResult = `Amazon offers the lowest price when compared to Myntra: ₹${amazonPrice}`;
  } else {
    comparisonResult = `Both Myntra and Amazon offer the same price: ₹${myntraPrice}`;
  }
  console.log(comparisonResult);

  // --- GENERATE DETAILED TEST REPORT ---
  const testReport = {
    searchTerm: searchTerm,
    platforms: {
      myntra: {
        productLink: myntraProductFullLink,
        productPrice: myntraPrice,
        screenshot: myntraScreenshotPath,
      },
      amazon: {
        productLink: amazonProductFullLink,
        productPrice: amazonPrice,
        screenshot: amazonScreenshotPath,
      },
    },
    comparisonResult: comparisonResult,
  };

  // Write the test report to a JSON file
  const reportPath = 'test-report.json';
  fs.writeFileSync(reportPath, JSON.stringify(testReport, null, 2), 'utf-8');
  console.log(`Test report generated: ${reportPath}`);

  await browser.close();
})();

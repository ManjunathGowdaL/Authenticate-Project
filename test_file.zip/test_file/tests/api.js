const { chromium } = require('playwright');
const axios = require('axios');
const fs = require('fs');

// Load Postman collection
const postmanCollection = JSON.parse(fs.readFileSync('/home/manjunath.gowda/Downloads/Authenticate mock Api.postman_collection.json', 'utf8'));

(async () => {
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    for (const item of postmanCollection.item) {
        if (item.request) {
            const method = item.request.method;
            const url = item.request.url.raw;
            const headers = item.request.header.reduce((acc, header) => {
                acc[header.key] = header.value;
                return acc;
            }, {});
            const body = item.request.body ? item.request.body.raw : null;

            try {
                const response = await axios({
                    method: method.toLowerCase(),
                    url: url,
                    headers: headers,
                    data: body
                });
                console.log(`Response for ${url}:`, response.data);
            } catch (error) {
                console.error(`Error for ${url}:`, error.message);
            }
        }
    }

    await browser.close();
})();
